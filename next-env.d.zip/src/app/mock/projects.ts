export const projectsData = [
    {
        title: "P1",
        description: "D1"
    },
    {
        title: "P2",
        description: "D2"
    },
    {
        title: "P3",
        description: "D3"
    },
];