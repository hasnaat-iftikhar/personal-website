export { faqsData } from './faqs';
export { projectsData } from './projects';
export { specialties, specialtyDetails } from './specialties';