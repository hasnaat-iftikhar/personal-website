export interface ProjectDetailGridProps {
    className?: string;
    label: string;
    description: string
}