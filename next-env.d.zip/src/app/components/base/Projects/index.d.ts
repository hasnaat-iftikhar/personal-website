export interface ProjectsProps {
    data: {
        title: string;
        description: string;
    }[]
};