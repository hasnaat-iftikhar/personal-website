export interface ServiceInfoProps {
    headline: string;
    title: string;
    description: string;
    image: string;
    reverse?: boolean
}