export interface AccordionProps {
    title: string;
    content: string;
}