export interface SectionHeaderProps {
    title: string;
    description?: string;
    titleClassName?: string;
    descriptionClassName?: string;
    children: ReactNode;
}